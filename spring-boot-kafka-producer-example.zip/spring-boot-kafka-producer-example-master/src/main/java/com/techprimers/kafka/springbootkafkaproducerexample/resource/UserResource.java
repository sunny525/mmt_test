package com.techprimers.kafka.springbootkafkaproducerexample.resource;

import com.techprimers.kafka.springbootkafkaproducerexample.avro.MyUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("kafka")
public class UserResource {

//    @Autowired
//    private KafkaTemplate<String, User> kafkaTemplate;

    @Autowired
    private KafkaTemplate<String, MyUser> kafkaTemplate;

    private static final String TOPIC = "Kafka_Example";

//    @GetMapping("/publish/{name}")
//    public String post(@PathVariable("name") final String name) {
//
//        kafkaTemplate.send(TOPIC, new User(name, "Technology", 12000L));
//
//        return "Published successfully";
//    }

    @GetMapping("/publish/avro")
    public String postAvroRecord() {

        MyUser myUser = new MyUser();
        myUser.setName("Mritunjay");
        myUser.setDesignation("Manager");
        kafkaTemplate.send(TOPIC, myUser);

        return "Published successfully";
    }
}
