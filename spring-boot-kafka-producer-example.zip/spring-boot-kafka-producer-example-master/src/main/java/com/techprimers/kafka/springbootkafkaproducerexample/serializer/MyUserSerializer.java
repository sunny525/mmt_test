package com.techprimers.kafka.springbootkafkaproducerexample.serializer;

import com.techprimers.kafka.springbootkafkaproducerexample.avro.MyUser;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

public class MyUserSerializer implements Serializer<MyUser> {
    @Override public void configure(Map<String, ?> map, boolean b) {
    }
    @Override public byte[] serialize(String arg0, MyUser arg1) {
        byte[] retVal = serealizeAvroMyUser(arg1);
        return retVal;
    }
    @Override public void close() {
    }
    public byte[] serealizeAvroMyUser(MyUser myUser) {
        byte[] data = SerializationUtils.serialize(myUser);
        return data;
    }
}