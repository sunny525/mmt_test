package com.techprimers.kafka.springbootkafkaconsumerexample.deserializer;

import com.techprimers.kafka.springbootkafkaconsumerexample.avro.MyUser;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.kafka.common.serialization.Deserializer;

import java.util.Map;

public class MyUserDeserializer implements Deserializer<MyUser> {

    @Override public void close() {
    }

    @Override public void configure(Map<String, ?> arg0, boolean arg1) {
    }

    @Override
    public MyUser deserialize(String arg0, byte[] arg1) {
        MyUser myUser = deserealizeAvroMyUser(arg1);
        return myUser;
    }

    public MyUser deserealizeAvroMyUser(byte[] data) {
        MyUser myUser = null;
        try{
            myUser = SerializationUtils.deserialize(data);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return myUser;
    }
}
